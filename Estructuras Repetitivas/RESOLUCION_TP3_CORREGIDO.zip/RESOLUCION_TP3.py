#ejercicio 1
#Delimita el rango de números y se imprime
for cont in range(0,101):
    print(cont)

#ejercicio 2
#Ingresa un número entero
num = int(input("Ingrese un número entero: "))
#Se usa el if para el caso de que el número ingresado sea 0
if num == 0:
    print("El número ingresado tiene 1 dígito")
else:
    cont = 0
#Se cuentan los dígitos del número ingresado mediante el while
    while num != 0:
        num //= 10     #num = num // 10
        cont += 1      #cont = cont + 1
    print(f"El número ingresado tiene {cont} dígitos")

#ejercicio 3
#Se ingresa dos números enteros
num_1 = int(input("Ingrese un número entero: "))
num_2 = int(input("Ingrese un número entero: "))
#Se usa el if para el caso de que el segundo número ingrersado sea menor al primero
if num_1 < num_2:
    menor = num_1
    mayor = num_2
else:
    menor = num_2
    mayor = num_1
#Se inicia el contador de la suma en 0
suma = 0
#Se suma todos los números enteros comprendidos entre los números ingresados
for i in range(menor + 1, mayor):
    suma += i

print(f"La suma entre todos los números enteros comprendidos entre {num_1} y {num_2} es de: {suma}")

#ejercicio 4
#Se inicia el contador de la suma en 0
suma = 0
#Se ingresa un número entero
num = int(input("Ingrese un número entero: "))
#Si el número ingresado es distinto de 0 se suma 
while num != 0:
    suma += num
    num = int(input("Ingrese otro número entero: "))
#Se imprime el resultado de la suma
print(f"El total acumulado es de: {suma}")

#ejercicio 5
#Se importa un número random
import random
numero_aleatorio = random.randint(0, 9)
#Se inicia el contador de intentos 
intentos = 1
#Se ingresa un número para adivinar
num = int(input("Adivina el número entre 0 y 9: "))
#Mientras el número ingresado sea incorrecto ingresa en el while y se pide otro
while num != numero_aleatorio: 
    num = int(input("Número equivocado, ingrese otro: "))
    intentos += 1
#Imprime cuando el número es el correcto
print(f"Adivinaste el número!!! Lo adivinaste en {intentos} intentos.")

#ejercicio 6
#Delimita el rango de números y se imprime
for cont in range(99,0,-1):
    print(cont)

#ejercicio 7
#Se ingresa un número
numero = int(input("Ingrese un número: "))
#Se inicia el contador de la suma en 0
suma = 0
#Se delimita el rango de los números a sumar
for i in range(0,numero + 1):
    suma += i 
#Se imprime el resultado de la suma
print(f"La suma entre todos los números enteros comprendidos entre 0 y {numero} es de: {suma}")

#ejercicio 8
par = 0
impar = 0
num_pos = 0
num_negativo = 0

for i in range (6):
    numero = int(input("Ingresa un número entero: "))

    if numero % 2 == 0: 
        par += 1
    else:
        impar += 1

    if numero > 0:
        num_pos += 1
    else:
        num_negativo += 1

print(f"Hay {par} números pares, {impar} números impares, {num_pos} números positivos y {num_negativo} números negativos")
        
#ejercicio 9
contador = 0
suma = 0
for i in range (5):
    numero = int(input("Ingresa un número entero: "))
    contador += 1
    suma += numero
    promedio = suma / contador
print(f"El promedio de los números ingresados es de:{promedio} ",)

#ejercicio 10
numero = int(input("Ingresar un número entero: "))

numero_invertido = 0

while numero != 0:
    ultimo_digito = numero % 10
    numero_invertido = (numero_invertido * 10) + ultimo_digito
    numero //= 10

print(f"El número con los dígitos dados vuelta es: {numero_invertido}")