#ejercicio 1
print("Hola mundo!")

#ejercicio 2
nombre = input("Ingrese su nombre: ")
print(f"¡Bienvenido {nombre}!")

#ejercicio 3
nombre = input("Ingrese su nombre: ")
apellido = input("Ingrese su apellido: ")
edad = input("Ingrese su edad: ")
lugar_residencia = input("Ingrese su lugar de residencia: ")
print(f"Soy {nombre} {apellido}, tengo {edad} años y vivo en {lugar_residencia}")

#ejercicio 4 
radio = float(input("Ingrese el radio de un círculo: "))
area = 3.14 * radio ** 2
perimetro = 2 * 3.14 * radio

print(f"El área del círculo es {area} y su perímetro de {perimetro}")

#ejercicio 5
seg = int(input("Ingrese una cantidad de segundos: "))
horas = seg / 3600

print(f"{seg} segundos son {horas} horas")

#ejercicio 6
m1 = int(input("Ingrese un número: "))
x1 = m1 * 1
x2 = m1 * 2
x3 = m1 * 3
x4 = m1 * 4 
x5 = m1 * 5
x6 = m1 * 6
x7 = m1 * 7
x8 = m1 * 8
x9 = m1 * 9
x10 = m1 * 10

print(f"La tabla del número que ingresó es: {m1}x1={x1}, {m1}x2={x2}, {m1}x3={x3}, {m1}x4={x4}, {m1}x5={x5}, {m1}x6={x6}, {m1}x7={x7}, {m1}x8={x8}, {m1}x9={x9}, {m1}x10={x10}")

#ejercicio 7
n1 = int(input("Ingresa un número distinto de cero: "))
n2 = int(input("Ahora otro con la misma especificación: "))
suma = n1 + n2
resta = n1 - n2
mult = n1 * n2
div = n1 / n2

print(f"La suma de estos números es {suma}, la resta {resta}, la multiplicación {mult} y la división {div}.")

#ejercicio 8
altura = float(input("Ingrese su altura en metros: "))
peso = float(input("Ingrese su peso en kg: "))
imc = peso / (altura ** 2)

print(f"Su índice de masa corporal es de: {imc}")

#ejercicio 9
cel = float(input("Ingrese una temperatura en grados Celsius: "))
far = (9 / 5) * cel + 32

print(f"El equivalente en grados Fahrenheit es: {far}")

#ejercicio 10
num1 = float(input("Ingrese un número: "))
num2 = float(input("Ingrese un segundo número: "))
num3 = float(input("Ingrese un tercer número: "))
prom = (num1 + num2 + num3) / 3

print(f"El promedio es de: {prom}")